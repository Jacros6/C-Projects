//
// Created by Jacob Rosner 1/30/20
//

#ifndef GENERALBACKBONEPROGRAMS_DICTIONARY_HPP
#define GENERALBACKBONEPROGRAMS_DICTIONARY_HPP

#include<iostream>
#include<fstream>
#include<vector>
#include<tuple>
#include<stack>
#include <string>

class Maze {
public:
    Maze(std::string inputFileName);
    //int size();
   // std::vector<std::string> pathFromTo(std::string from, std::string to);
    //int member(std::string word);
    void printMaze();
    void mazeEntrances();
    void mazePathFromTo();
    ~Maze();

private:
    std::vector<std::string> maze;
    //std::vector<std::string> words;
    std::vector<std::string> used;
    std::stack<std::tuple<int, int>> path;
    std::tuple<int, int> startPath, targetPath;
    std::ifstream mazeStream;  // use it to open the input file.
    //std::vector<std::string> vec;
    int positionalDiff(std::string word1, std::string word2);
    int idxOfSuccessorWordFrom(std::string word, int fromIdx);
    void printPath();
    void resetPath(); // this function sets all elements of array "used" to false.


    std::tuple<int, int> nextCell(std::tuple<int, int> cell);

};

//std::cout << std::get<0>(mytuplename);
//std::cout << std::get<1>(mytuplename);
#endif //GENERALBACKBONEPROGRAMS_DICTIONARY_HPP
