//
// Created by Jacob Rosner 1/30/20
//
#include<iostream>
#include"Maze.hpp"

int main(int argc, char *argv[]) {
    if( argc != 2 ) {
        std::cout << "usage: " << argv[0] << " inputFileNameThatContainsMaze \n";
        exit(1);
    }
    std::ifstream mazeStream;
    mazeStream.open(argv[1], std::ios_base::in);
    if( ! mazeStream.is_open()) {
        std::cout << "Unable to open input file ->" << argv[1] << "<-\n";
        exit(2);
    }
    std::cout << "Successfully opened " << argv[1] << std::endl;
    mazeStream.close();
    Maze maze(argv[1]);
    std::cout << "Enterances to my maze being looked for" << std::endl;
    maze.mazeEntrances();
    std::cout << "Attempting to find a path" << std::endl;
    maze.mazePathFromTo();
    return 0;
}
