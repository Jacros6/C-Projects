Jacob Rosner Project 1 2/7/20

Everything should work for the maze problem.
I have tested many times using the given maze in Canvas and
I changed up the entrances of the maze so that my program
can find an entrance and an exit on every side of the maze.
If there is no entrance my program will exit and report
it's failure. I think that my program will work given a different
main file. I just call my mazeEntrances() prior to calling my
mazePathFromTo() function. You might need to include in the main that
will be tested mazeEntrances() in order to proceed with the program.
I am able to return our original maze with a blank path indicating
path from my start coordinates to my end coordinates. If a path is not found the
program will let me know.