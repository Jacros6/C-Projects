//
// Created by Jacob Rosner 1/30/20
//

#include <iostream>
#include <fstream>
//#include <ifstream>
#include "Maze.hpp"

Maze::Maze(std::string inputFileName) {
    std::cout << "Creating an instance of Maze with input file: " << inputFileName << std::endl;
    mazeStream.open(inputFileName);
    std::string str;
    while (std::getline(mazeStream, str)) {
        maze.push_back(str);
    }
    resetPath();
}

Maze::~Maze() {
    if (mazeStream.is_open())
        mazeStream.close();
}

void Maze::printMaze() {
    for (int i = 0; i < maze.size(); i++) {
        std::cout << maze[i] << std::endl;
    }
}

void Maze::printPath() {
    if(path.empty()){
        std::cout << "Theres nothing to print" << std::endl;
        return;
    }
    int size = path.size();
    for(int i = 0; i < size; i++){
        maze[std::get<0>(path.top())][std::get<1>(path.top())] = ' ';
        path.pop();
    }
    for(int i = 0; i < maze.size(); i++){
        std::cout << maze[i] << std::endl;
    }
}

void Maze::resetPath() {
    used.resize(maze.size());
    for (int i = 0; i < used.size(); i++) {
        used[i] = maze[i];
    }
    for(int i = 0; i < used.size(); i++){
        std::cout << used[i] << std::endl;
    }
}

void Maze::mazeEntrances(){
    //resetPath();
    for(int i = 0; i < maze.size(); i++){ //left side
        if(used[i][0] == '0'){
            startPath = std::make_tuple(i, 0);
	    std::cout << "Left Side Start Path" << std::endl;
            break;
        }
    }
    for(int i = 0; i < maze[0].size() - 1; i++){ //top side
        if(used[0][i] == '0'){
            startPath = std::make_tuple(0, i);
	    std::cout << "Top Side Start Path" << std::endl;
            break;
        }
    }
    for(int i = 0; i < maze.size(); i++){ //right side
        if(used[i][used[i].size() - 1] == '0'){
            startPath = std::make_tuple(i, used[i].size() - 1);
	    std::cout << "Right Side Start Path" << std::endl;
            break;
        }
    }
    for(int i = 0; i < maze[0].size() - 1; i++){ //bottom side
        if(used[used.size() - 1][i] == '0'){
            startPath = std::make_tuple(used.size() - 1, i);
	    std::cout << "Bottom Side Start Path" << std::endl;
            break;
        }
    }

    for(int i = 0; i < maze.size(); i++){ //left side target
        if(used[i][0] == '0'){
            targetPath = std::make_tuple(i, 0);
            if(targetPath != startPath){
                return;
            }
        }
    }
    for(int i = 0; i < maze[0].size() - 1; i++){ //top side target
        if(used[0][i] == '0'){
            targetPath = std::make_tuple(0, i);
            if(targetPath != startPath){
                return;
            }
        }
    }
    for(int i = 0; i < maze.size() - 1; i++){ //right side target
        if(used[i][used[i].size() - 2] == '0'){
            targetPath = std::make_tuple(i, used[i].size() - 2);
            if(/*targetPath != startPath*/std::get<0>(targetPath) != std::get<0>(startPath) 
			    && std::get<1>(targetPath) != std::get<1>(startPath)){
                return;
            }
        }
    }
    for(int i = 0; i < maze[0].size() - 1; i++){ //bottom side target
        if(used[used.size() - 1][i] == '0'){
            targetPath = std::make_tuple(used.size() - 1, i);
            if(targetPath != startPath){
                return;
            }
        }
    }
    std::cout << std::get<0>(startPath) << std::get<1>(startPath) << std::endl;
    std::cout << std::get<0>(targetPath) << std::get<1>(targetPath) << std::endl;
    std::cout << "This maze may not have a beginning or end, exiting" << std::endl;
    exit(1);
}

std::tuple<int, int>Maze::nextCell(std::tuple<int, int> cell){
    int row = std::get<0>(cell);
    int column = std::get<1>(cell);
    if(row != 0 && used[row - 1][column] == '0'){
        return std::make_tuple(row - 1, column);
    }
    if(column != used[0].size() - 1 && used[row][column + 1] == '0'){
        return std::make_tuple(row, column + 1);
    }
    if(row != used.size() - 1 && used[row + 1][column] == '0'){
        return std::make_tuple(row + 1, column);
    }
    if(column != 0 && used[row][column - 1] == '0'){
        return std::make_tuple(row, column - 1);
    }
    return std::make_tuple(-1, -1);
}

void Maze::mazePathFromTo(){
    path.push(targetPath);
    std::tuple<int, int> next = targetPath;
    while(!path.empty()) {
        if (nextCell(next) == std::make_tuple(-1, -1)){
            path.pop();
            next = path.top();
        } else {
            next = nextCell(next);
            path.push(next);
            used[std::get<0>(next)][std::get<1>(next)] = '1';
            if(next == startPath){
                break;
            }
        }
    }
    if(path.empty()){
        std::cout << "There is no path from the start cell to the target cell" << std::endl;
        exit(1);
    }
    if(!path.empty()){
        std::cout << "Found a path!" << std::endl;
        printPath();
    }
}

