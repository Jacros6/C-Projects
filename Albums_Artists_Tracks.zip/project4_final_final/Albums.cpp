#include "Albums.hpp"

Albums::Albums(){

}

void Albums::openFile(std::string fileName){
    inputStream.open(fileName, std::ios::in);
    readJSONArrayAlbums(inputStream);
    inputStream.close();
}

std::vector<Album *> Albums::getArtistsWithAlbums_vec(){
   return newAlbum_vec;

}

void Albums::clear(){
    newAlbum_vec.clear();
}

std::vector<Album*> Albums::albumsForArtist(Artist *artistAtElement) {
    std::vector<Album *>albumsForArtist;
    Album *album = new Album();
    int size = albums_vec.size();
    for(int i = 0; i < size; i++){
        album = albums_vec[i];
        if(album->artistID() == artistAtElement->artistID()){
            newAlbum_vec.push_back(album);
            //albumsForArtist.push_back(album);
        }
    }
    return newAlbum_vec;
    //return albumsForArtist;
}

Albums::~Albums(){

}

int Albums::albumsVecSize(){
    return albums_vec.size();
}

std::vector<Tracks *> Albums::addTracks(Tracks *tracks){
    albumsWithTracks_vec.push_back(tracks);
    return albumsWithTracks_vec;
}

void Albums::readJSONArrayAlbums(std::fstream &stream)
{
    char c;

    if( !(stream >> c) || c != '[' ) {  // the first non-space character is expected to be '['
        std::cout << "Something is wrong character is " << c << " while it should be a : '['... exit ";
        exit(1);
    }
    do {
        //artist.readJSONDataObject(stream);
        //artists_vec.push_back(artist);
        Album* album = new Album;
        album->readJSONDataObject(stream); //change to parsepair function
        albums_vec.push_back(album);
        stream >> c;
    }
    while( c != ']' );
}

Album *Albums::getAlbumPair(int i) {
    return albums_vec[i];
}


//Albums *almbumsforartist(ARtist *artist){
//Albums *almbums = new Albums();
//for each album in this albums
//if (album->artistID() == artist->artistID())
//albums->addAlbum(album)
//
//new function
//may be in main function
//Albums allAlbums = create an instance of albums and parse each album
// has access to an instance in Albums
//void Artists::assignAlbums(){
//for each artist in Artists
//artist->addAlbums(allAlbums->albumsForArtist(artist));