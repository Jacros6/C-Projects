#include<fstream>
#include<cstring>
#include<vector>
#include<string>
#include <sstream>
#include <iostream>
#include "Pair.hpp"


class AlbumImage
{
public:
    AlbumImage();
    ~AlbumImage();
    void readJSONDataObject(std::fstream &stream);
    std::string albumID();
    std::string type();
    std::string width();
    std::string height();
    std::string uri();
private:
    std::fstream inputStream;
    std::vector<Pair*> albumImage_vec;

};
