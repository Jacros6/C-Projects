#include "ArtistImages.hpp"

ArtistImages::ArtistImages(){

}

ArtistImages::~ArtistImages(){

}

void ArtistImages::clear(){
    newArtistImages_vec.clear();
}

std::vector<ArtistImage*> ArtistImages::artistImagesForArtist(Artist * artistAtElement){
    ArtistImage *artistImage = new ArtistImage();
    int size = artistImages_vec.size();
    for(int i = 0; i < size; i++){
        artistImage = artistImages_vec[i];
        if(artistImage->artistID() == artistAtElement->artistID()){
            newArtistImages_vec.push_back(artistImage);
            //albumsForArtist.push_back(album);
        }
    }
    return newArtistImages_vec;
}

std::vector<ArtistImage*> ArtistImages::getArtistImages_vec(){
    return newArtistImages_vec;
}

void ArtistImages::openFile(std::string fileName){
    inputStream.open(fileName, std::ios::in);
    readJSONArray(inputStream);
    inputStream.close();
}

void ArtistImages::readJSONArray(std::fstream &stream)
{
    char c;

    if( !(stream >> c) || c != '[' ) { // The first non-space character of a JSON object has to be '['.
        // print some error message and exit the program.
        std::cout << "Something is wrong character is " << c << " while it should be a : '['... exit ";
        exit(1);}
    do {
        ArtistImage *artistImage = new ArtistImage;
        artistImage->readJSONDataObject(stream);
        artistImages_vec.push_back(artistImage);
        stream >> c;
    } while( c != ']' );

}