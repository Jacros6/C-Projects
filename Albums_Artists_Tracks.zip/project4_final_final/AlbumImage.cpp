#include "AlbumImage.hpp"

AlbumImage::~AlbumImage(){

}

AlbumImage::AlbumImage(){

}

std::string AlbumImage::albumID(){
    Pair * pair;/*= new Pair;*/
    pair = albumImage_vec[0];
    return pair->attributeName();
}

std::string AlbumImage::height() {
    Pair * pair;
    pair = albumImage_vec[3];
    return pair->attributeName();
}

std::string AlbumImage::width(){
    Pair * pair;
    pair = albumImage_vec[2];
    return pair->attributeName();
}

std::string AlbumImage::uri() {
    Pair * pair;
    pair = albumImage_vec[4];
    return pair->attributeName();
}

std::string AlbumImage::type() {
    Pair * pair;
    pair = albumImage_vec[1];
    return pair->attributeName();
}



void AlbumImage::readJSONDataObject(std::fstream &stream)
{
    char c;

    if( !(stream >> c) || c != '{' ) { // The first non-space character of a JSON object has to be '{'.
        // print some error message and exit the program.
        std::cout << "Something is wrong character is " << c << " while it should be a : '{'... exit ";
        exit(1);}
    do {
        Pair *pair = new Pair;
        pair->parsePair(stream);
        albumImage_vec.push_back(pair);
        stream >> c;
    } while( c != '}' );

}

