#ifndef ARTISTIMAGE_HPP
#define ARTISTIMAGE_HPP
#include<fstream>
#include<cstring>
#include<vector>
#include<string>
#include <sstream>
#include <iostream>
#include "Pair.hpp"


class ArtistImage {
public:
    ArtistImage();
    ~ArtistImage();
    void readJSONDataObject(std::fstream &stream);
    std::string artistID();
    std::string type();
    std::string width();
    std::string height();
    std::string uri();
private:
    std::fstream inputStream;
    std::vector<Pair *> artistImage_vec;


};

#endif //ArtistImage.hpp