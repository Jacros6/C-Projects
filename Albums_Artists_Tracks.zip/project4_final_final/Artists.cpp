#include "Artists.hpp"

Artists::Artists(){

}

void Artists::openFile(std::string fileName){
    inputStream.open(fileName, std::ios::in);
    readJSONArray(inputStream);
    inputStream.close();
    //In Albums make a funciton that takes in an Artist
    //I can use my Artists vector to do that
    //returns an instance of Albums for that artist

    //I have access to one Artist and Albums, I put this Artist in Albums
    //In a function in Albums AlbumforArtist
    //Takes the Artist and gives you an instance of Albums'
    //Same thing for Albums to tracks
    //function TracksforAlbum
}

void Artists::openHTMLFile(std::string filename){
    HTMLStream.open(filename, std::ios::in);

}

Artists::~Artists(){

}

Artist* Artists::getArtistsPair(int counter) {
    return artists_vec[counter];
}

void Artists::readJSONArray(std::fstream &stream)
{
    char c;

    if( !(stream >> c) || c != '[' ) {  // the first non-space character is expected to be '['
        std::cout << "Something is wrong character is " << c << " while it should be a : '['... exit ";
        exit(1);
    }
    do {
        Artist* artist = new Artist;
        artist->readJSONDataObject(stream); //change to parsepair function
        artists_vec.push_back(artist);
        stream >> c;
    }
    while( c != ']' );
}
