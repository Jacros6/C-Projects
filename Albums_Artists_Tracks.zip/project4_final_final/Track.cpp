#include "Track.hpp"

Track::~Track(){

}

Track::Track(){

}

std::string Track::albumID() {
    Pair * pair = new Pair;
    pair = track_vec[0];
    return pair->attributeName();
}

std::string Track::albumName() {
    Pair * pair = new Pair;
    pair = track_vec[1];
    return pair->attributeName();
}

std::string Track::artistName() {
    Pair * pair = new Pair;
    pair = track_vec[2];
    return pair->attributeName();
}

std::string Track::position() {
    Pair * pair = new Pair;
    pair = track_vec[3];
    return pair->attributeName();
}

std::string Track::duration(){
    Pair * pair = new Pair;
    pair = track_vec[4];
    return pair->attributeName();
}

std::string Track::title(){
    Pair * pair = new Pair;
    pair = track_vec[5];
    return pair->attributeName();
}

std::string Track::printTracks(){
    std::string htmlBody;
    htmlBody = "<br><tbody><tr>Title:" + track_vec[5]->attributeName() +"</tr></tbody>" +
               "<tbody><tr>Duration: " + track_vec[4]->attributeName() + "</tr></tbody></br>";
    return htmlBody;
}

void Track::readJSONDataObject(std::fstream &stream)
{
    char c;

    if( !(stream >> c) || c != '{' ) {
        std::cout << "Something is wrong character is " << c << " while it should be a : '{'... exit ";
        exit(1);}
    do {
        Pair *pair = new Pair;
        pair->parsePair(stream);
        track_vec.push_back(pair);
        stream >> c;

    } while( c != '}' );

}
