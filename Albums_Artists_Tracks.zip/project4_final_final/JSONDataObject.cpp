#include "JSONDataObject.hpp"

/*void parseDataObject(std::fstream){

}*/