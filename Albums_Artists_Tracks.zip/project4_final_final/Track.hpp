#include<fstream>
#include<cstring>
#include<vector>
#include<string>
#include <sstream>
#include <iostream>
#include "Pair.hpp"

class Track
{
public:
    Track();
    ~Track();
    void readJSONArray(std::fstream &stream);
    void readJSONDataObject(std::fstream &stream);
    void readJSONDataItem(std::fstream &stream);
    void openFile(std::string fileName);
    std::string albumID();
    std::string albumName();
    std::string artistName();
    std::string position();
    std::string duration();
    std::string title();
    std::string printTracks();
private:
    std::fstream inputStream;
    std::vector<Pair*> track_vec;

};
