#include <vector>
#include <fstream>
#include <iostream>
#include "Album.hpp"
#include "Artist.hpp"
#include "Tracks.hpp"
#include "AlbumImages.hpp"

class Albums{
public:
    Albums();
    void openFile(std::string);
    //Albums(std::string);
    ~Albums();
    void readJSONArrayAlbums(std::fstream &stream);
    std::vector<Album*> albumsForArtist(Artist *);
    void readJSONDataObject(std::fstream &stream);
    void loadArtistsFromFile(std::string fileName);
    std::string htmlString();
    int albumsVecSize();
    std::vector<Album*> getAlbumVec();
    Album *getAlbumPair(int i);
    std::vector<Tracks *> addTracks(Tracks *tracks);
    std::vector<Album *> getArtistsWithAlbums_vec();
    void clear();
private:
    std::fstream inputStream;
    std::vector<Album*> albums_vec;
    std::vector<Tracks*> albumsWithTracks_vec;
    std::vector<Album*> newAlbum_vec;
    std::vector<Album*> artistsWithAlbums_vec;
};