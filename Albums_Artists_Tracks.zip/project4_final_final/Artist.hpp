#ifndef ARTIST_HPP
#define ARTIST_HPP

#include<fstream>
#include<cstring>
#include<vector>
#include<string>
#include <sstream>
#include <iostream>
#include "Pair.hpp"



class Artist{
public:
    Artist();
    //Artist(std::string fileName);
    Artist(const Artist&);

    Artist(std::fstream stream);
    std::string artistID();
    std::string num_Images();
    std::string profile();
    std::string artist_name();
    ~Artist();
    //void addAlbums(Albums * albums);
    void readJSONDataObject(std::fstream &stream);
    std::vector<Pair *> artist_vec;
private:
    //std::vector<Albums *> albums_vec;


};

#endif //Artist.hpp
