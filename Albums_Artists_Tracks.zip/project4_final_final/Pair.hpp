#ifndef PAIR_HPP
#define PAIR_HPP
#include<fstream>
#include<cstring>
#include<vector>
#include<string>
#include <sstream>
#include <iostream>


class Pair {
    // represents a entity and its value:

public:
    Pair();
    ~Pair();
    Pair(std::string attributeName, std::string attributeValue);
    Pair(std::string attributeName, int);
    bool isNumber();  // is the datatype of the value of this entity integer?
    int numberValue();
    std::string stringValue();
    std::string attributeName();
    void parsePair(std::fstream &stream);
    std::string parseJSONString(std::string string, char c, std::fstream &stream);

private:
    std::string _attributeName, _attributeStringValue;
    int _attributeNumberValue;
    bool _isNumber;
};

#endif //Pair.hpp