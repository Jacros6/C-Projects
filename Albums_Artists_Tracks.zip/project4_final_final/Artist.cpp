#include "Artist.hpp"

Artist::Artist(){

}

Artist::Artist(std::fstream stream){

}

Artist::~Artist(){

}

Artist::Artist(const Artist &old_artist){

}

std::string Artist::artistID(){
    Pair * pair = new Pair;
    pair = artist_vec[1];
    return pair->attributeName();
}

std::string Artist::artist_name() {
    Pair * pair = new Pair;
    pair = artist_vec[4];
    return pair->attributeName();
}
std::string Artist::num_Images() {
    Pair * pair = new Pair;
    pair = artist_vec[0];
    return pair->attributeName();
}
std::string Artist::profile() {
    Pair * pair = new Pair;
    pair = artist_vec[2];
    return pair->attributeName();
}

void Artist::readJSONDataObject(std::fstream &stream)
{
    char c;

    if( !(stream >> c) || c != '{' ) {
        std::cout << "Something is wrong character is " << c << " while it should be a : '{'... exit ";
        exit(1);}
    do {

        Pair* pair = new Pair;
        pair->parsePair(stream);
        artist_vec.push_back(pair);

        stream >> c;
    } while( c != '}' );

}
