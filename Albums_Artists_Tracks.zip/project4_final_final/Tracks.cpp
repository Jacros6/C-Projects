#include "Tracks.hpp"

Tracks::Tracks(){

}

void Tracks::openFile(std::string fileName){
    inputStream.open(fileName, std::ios::in);
    readJSONArray(inputStream);
    inputStream.close();
}

Tracks::~Tracks(){

}

std::vector<Track *> Tracks::getAlbumsWithTracks_vec(){
    return newTracks_vec;
}

void Tracks::clear(){
    newTracks_vec.clear();
}

std::vector<Track*> Tracks::tracksForAlbums(Album *albumAtElement){
    Track *track = new Track;
    int size = tracks_vec.size();
    for(int i = 0; i < size; i++){
        track = tracks_vec[i];
        if(track->albumID() == albumAtElement->albumID()){
            newTracks_vec.push_back(track);
        }
    }
    return newTracks_vec;
}

void Tracks::readJSONArray(std::fstream &stream)
{
    char c;

    if( !(stream >> c) || c != '[' ) {  // the first non-space character is expected to be '['
        std::cout << "Something is wrong character is " << c << " while it should be a : '['... exit ";
        exit(1);
    }
    do {
        Track* track = new Track;
        track->readJSONDataObject(stream); //change to parsepair function
        tracks_vec.push_back(track);
        stream >> c;
    }
    while( c != ']' );
}
