//#include "Album.hpp"
#include "Artists.hpp"
//#include "ArtistImage.hpp"
//#include "AlbumImage.hpp"
//#include "Tracks.hpp"
#include <string>
#include <fstream>

int main(int argc, char *argv[]){
/*    if(argc != 4){
        std::cout << "Not enough arguments should be 4" << std::endl;
        exit(1);
    }*/
 /*   if(argv[1] == "artist_human_readable.json") {
        file1.open(argv[1], std::ios::in);
        Artist(file1);
    }*/
    std::string html = "htmlMasterFile.html";
    std::fstream htmlStream;
    std::string htmlTop = "<!DOCTYPE html><html><body>";
    htmlStream.open(html, std::ios::out);
    htmlStream << htmlTop;
    std::vector<std::vector<Album*>> sortedAlbumsforArtist;
    std::vector<std::vector<Track*>> sortedTracksforAlbums;
    std::vector<std::vector<ArtistImage*>> sortedArtistImagesforArtists;
    std::vector<std::vector<AlbumImage*>> sortedAlbumImagesforAlbums;

    Artists* artists = new Artists;
    artists->openFile(argv[1]);

    Albums* albums = new Albums;
    albums->openFile(argv[2]);

    Tracks* tracks = new Tracks;
    tracks->openFile(argv[3]);

    ArtistImages* artistImages = new ArtistImages;
    artistImages->openFile(argv[4]);

    AlbumImages* albumImages = new AlbumImages;
    albumImages->openFile(argv[5]);

    int size = artists->artistVecSize();
    for(int i = 0; i < size; i++){
        albums->albumsForArtist(artists->getArtistsPair(i));
        sortedAlbumsforArtist.push_back(albums->getArtistsWithAlbums_vec());
        albums->clear();
    }

    size = albums->albumsVecSize();
    for(int i = 0; i < size; i++){
        tracks->tracksForAlbums(albums->getAlbumPair(i));
        sortedTracksforAlbums.push_back(tracks->getAlbumsWithTracks_vec());
        tracks->clear();
    }

    size = artists->artistVecSize();
    sortedArtistImagesforArtists.push_back((artistImages->getArtistImages_vec()));
    for(int i = 0; i < size; i++){
        artistImages->artistImagesForArtist(artists->getArtistsPair(i));
        sortedArtistImagesforArtists.push_back(artistImages->getArtistImages_vec());
        artistImages->clear();
    }

    size = albums->albumsVecSize();
    sortedAlbumImagesforAlbums.push_back((albumImages->getAlbumImages_vec()));
    for(int i = 0; i < size; i++){
        albumImages->albumImagesForAlbums(albums->getAlbumPair(i));
        sortedAlbumImagesforAlbums.push_back(albumImages->getAlbumImages_vec());
        albumImages->clear();
    }

    size = artists->artistVecSize();
    std::string htmlBody;
    std::vector<ArtistImage*> newArtistImages_vec;
    std::vector<AlbumImage*> newAlbumImages_vec;
    std::vector<Album*> newAlbum_vec;
    std::vector<Track*> newTracks_vec;
    Artist *artist = new Artist;
    Album *album = new Album;
    ArtistImage* artistImage = new ArtistImage;
    Track *track = new Track;
    for(int i = 0; i < size; i++){
        artist = artists->getArtistsPair(i);
        if(!sortedArtistImagesforArtists[i].empty()) {//Images for Artist
            newArtistImages_vec = sortedArtistImagesforArtists[i];
            htmlBody = "<img class = \"image\"src=" + newArtistImages_vec[0]->uri() + ">";
            htmlStream << htmlBody;
            htmlBody = "<img class = \"image\"src=" + newArtistImages_vec[1]->uri() + ">";
            htmlStream << htmlBody;
        }
        htmlBody = "<h2>" + artist->artist_name() + "</h2>";
        htmlStream << htmlBody;
        htmlBody = "<br><tbody><tr>Number of Images:" + artist->num_Images()+"</tr></tbody></br>" + "<br><tbody><tr>Profile: " + artist->profile() + "</tr></tbody></br>";
        htmlStream << htmlBody;
        htmlBody = "<h2>Albums</h2>";
        htmlStream << htmlBody;
        newAlbum_vec = sortedAlbumsforArtist[i];
        for(int j = 0; j < newAlbum_vec.size(); j++){  //TODO images for albums works but depends on albums
		//there are no albums apparently so that needs to be fixed
            newAlbumImages_vec = sortedAlbumImagesforAlbums[j];
            htmlBody = "<br><tbody><tr>Artist Name: " + artist->artist_name() + "</tr></tbody></br>";
            htmlStream << htmlBody;
	    htmlBody = sortedAlbumsforArtist[i][j]->printAlbums();
            htmlBody = newAlbum_vec[j]->printAlbums();
            htmlStream << htmlBody;
	    //NEW THING ADDED HERE
	    //newAlbumImages_vec = sortedAlbumImagesforAlbums[j + 1];
	    //htmlBody = "<br><tbody><tr><img class = \"image\"src=" + newAlbumImages_vec[0]->uri() + ">" +"</tr></tbody></br>";
	    //htmlStream << htmlBody;

            if(!sortedAlbumImagesforAlbums[j + 1].empty()) {
                for(int r = 0; r < sortedAlbumImagesforAlbums.size(); r++) {
                    if(!sortedAlbumImagesforAlbums[r + 1].empty()) {
                        if (/*newAlbum_vec[j]->albumID()*/sortedAlbumsforArtist[i][j]->albumID() == sortedAlbumImagesforAlbums[r + 1][0]->albumID()) {
                            newAlbumImages_vec = sortedAlbumImagesforAlbums[r + 1];
                            htmlBody =
                                    "<br><tbody><tr><img class = \"image\"src=" + newAlbumImages_vec[0]->uri() + ">" +
                                    "</tr></tbody></br>";
                            htmlStream << htmlBody;
                            htmlBody ="<br><tbody><tr><img class = \"image\"src=" + newAlbumImages_vec[1]->uri() + ">" +
                            "</tr></tbody></br>";
                            htmlStream << htmlBody;
                        }
                    }
                }
            }
            for(int z = 0; z < sortedTracksforAlbums.size(); z++){ //Correctly finds tracks for albums i think!
                newTracks_vec = sortedTracksforAlbums[z];
                for(int a = 0; a < newTracks_vec.size(); a++){
                    if(newTracks_vec[a]->albumID() == newAlbum_vec[j]->albumID()){
                        htmlBody = newTracks_vec[a]->printTracks();
                        htmlStream << htmlBody;
                    }
                }
            }
        }
        }
        //htmlBody = "<tbody><"
    htmlStream.close();
    return 0;
}
