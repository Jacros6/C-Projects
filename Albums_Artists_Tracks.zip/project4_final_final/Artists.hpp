#ifndef ARTISTS_HPP
#define ARTISTS_HPP
#include <vector>
#include <fstream>
#include "Artist.hpp"
#include "Albums.hpp"
#include "ArtistImages.hpp"

class Artists{
public:
    Artists();
    //Artists(std::string);
    ~Artists();
    void openFile(std::string);
    void readJSONArray(std::fstream &stream);
    Artist* getArtistsPair(int counter);
    int artistVecSize(){
        return artists_vec.size();
    }
    void openHTMLFile(std::string filename);
private:
    std::fstream inputStream;
    std::fstream HTMLStream;
    std::vector<Artist *> artists_vec;
};

#endif //Artists.hpp