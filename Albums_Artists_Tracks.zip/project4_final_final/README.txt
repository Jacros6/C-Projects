Project 4 README

everything should work

to compile the file use make or do this command

g++ *.cpp

for the a.out file that will be created to run the program one final time 

./a.out (and then the rest of the executable files in the order of
artist_human_readable, album_human_readable, track_human_readable, artistImages_human_readable, albumImages_human_readable)

all the information will go into a file called htmlMasterFile.html

I saw that you wanted it into a subdirectory but once again I was not sure how to do that so I ended up just doing it like so.


