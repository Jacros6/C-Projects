#include<fstream>
#include<vector>
#include <cstring>
#include <string>
#include <sstream>
#include <iostream>
#include "ArtistImage.hpp"
#include "Artist.hpp"


class ArtistImages {
public:
    ArtistImages();
    ~ArtistImages();
    void openFile(std::string fileName);
    std::vector<ArtistImage*> artistImagesForArtist(Artist *);
    void readJSONArray(std::fstream &stream);
    std::vector<ArtistImage*> getArtistImages_vec();
    void clear();
private:
    std::fstream inputStream;
    std::vector<ArtistImage*> artistImages_vec;
    std::vector<ArtistImage*> newArtistImages_vec;


};
