#include "AlbumImages.hpp"

AlbumImages::~AlbumImages(){

}

AlbumImages::AlbumImages(){

}

void AlbumImages::openFile(std::string fileName){
    inputStream.open(fileName, std::ios::in);
    readJSONArray(inputStream);
    inputStream.close();
}


void AlbumImages::readJSONArray(std::fstream &stream){
    char c;

    if( !(stream >> c) || c != '[' ) { // The first non-space character of a JSON object has to be '['.
        // print some error message and exit the program.
        std::cout << "Something is wrong character is " << c << " while it should be a : ']'... exit ";
        exit(1);}
    do {
        AlbumImage * albumImage = new AlbumImage;
        albumImage->readJSONDataObject(stream);
        albumImages_vec.push_back(albumImage);
        stream >> c;
    } while( c != ']' );
}

void AlbumImages::clear(){
    newAlbumImages_vec.clear();
}

std::vector<AlbumImage*> AlbumImages::albumImagesForAlbums(Album *albumAtElement) {
    std::vector<Album *>albumsForArtist;
    AlbumImage *albumImage = new AlbumImage();
    int size = albumImages_vec.size();
    for(int i = 0; i < size; i++){
        albumImage = albumImages_vec[i];
        if(albumImage->albumID() == albumAtElement->albumID()){
            newAlbumImages_vec.push_back(albumImage);
        }
    }
    return newAlbumImages_vec;
}

std::vector<AlbumImage*> AlbumImages::getAlbumImages_vec(){
    return newAlbumImages_vec;
}
