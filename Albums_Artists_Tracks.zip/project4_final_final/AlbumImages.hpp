#include<fstream>
#include<cstring>
#include<vector>
#include<string>
#include <sstream>
#include <iostream>
#include "AlbumImage.hpp"
#include "Album.hpp"

class AlbumImages
{
public:
    AlbumImages();
    ~AlbumImages();

    void readJSONArray(std::fstream &stream);
    void openFile(std::string fileName);
    std::vector<AlbumImage*> getAlbumImages_vec();
    std::vector<AlbumImage*> albumImagesForAlbums(Album *artistAtElement);
    void clear();
private:
    std::fstream inputStream;
    std::vector<AlbumImage*> albumImages_vec;
    std::vector<AlbumImage*> newAlbumImages_vec;


};
