#include "Pair.hpp"

Pair::Pair(){}

Pair::~Pair(){}

std::string Pair::attributeName() {
    return _attributeStringValue;
}

void Pair::parsePair(std::fstream &stream) {
    char c;
    std::string key;
    std::stringstream ss;
    std::string storage;
    if (!(stream >> c) || c != '"') {
        std::cout << "error" << std::endl;
        std::cout << c << std::endl;
        exit(1);
    }
    stream.get(c);
    while (c != '"') {
        key += c;
        stream.get(c);
    }
    key = key + "\"";
    _attributeName = key;
    if (!(stream >> c) || c != ':') {
        std::cout << "error" << std::endl;
    }
    stream >> c;
    if (isdigit(c)) {
        stream.unget();
        int number;
        stream >> number; //should get me the entire digit part
        ss << number;
        ss >> storage;
        _attributeStringValue = storage;
    } else {
        stream.unget();
        std::string string;
        stream.get(c);
        string = parseJSONString(string, c, stream); // this function here should give me the entire string part
        _attributeStringValue = string;
    }
}

std::string Pair::parseJSONString(std::string string, char c, std::fstream &stream){
    while(stream.get(c) && c != '"'){
        string+=c;
        if(c == '\\' && stream.peek() == '"'){
            stream.get(c);
            string+=c;
        }
    }
    return string;
}