#include <vector>
#include "Pair.hpp"
#include <fstream>

class JSONDataObject {
public:
    JSONDataObject();
    virtual ~JSONDataObject();
    std::vector<Pair *> *listOfDataItems() { return _listOfDataItems; }
    void parseDataObject(std::fstream);
    virtual void print();
    std::string valueForStringAttribute(std::string s);
    int valueForIntegerAttribute(std::string s);

private:
    std::vector<Pair *> *_listOfDataItems;
};