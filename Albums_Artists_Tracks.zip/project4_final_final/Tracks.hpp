#ifndef TRACKS_HPP
#define TRACKS_HPP
#include <vector>
#include <fstream>
#include "Track.hpp"
#include "Album.hpp"
#include "Pair.hpp"

class Tracks{
public:
    Tracks();
    //Artists(std::string);
    ~Tracks();
    void openFile(std::string);
    void readJSONArray(std::fstream &stream);
    std::vector<Track*> tracksForAlbums(Album *albumAtElement);
    std::vector<Track *> getAlbumsWithTracks_vec();
    void clear();
private:
    std::fstream inputStream;
    std::string htmlStr;
    std::vector<Track*> tracks_vec;
    std::vector<Track*> newTracks_vec;
};

#endif //Tracks.hpp