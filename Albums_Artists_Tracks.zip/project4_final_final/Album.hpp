#ifndef ALBUM_HPP
#define ALBUM_HPP
#include<fstream>
#include<cstring>
#include<vector>
#include<string>
#include <sstream>
#include <iostream>
#include "Pair.hpp"



class Album
{
public:
    Album();

    ~Album();
    Album(const Album &old_artist);
    Album(std::fstream stream);
    std::string artistID();
    std::string albumID();
    std::string num_tracks();
    std::string title();
    std::string genre();
    std::string year();
    std::string num_images();
    std::string printAlbums();
    void print();
    void parseFromJSONstream(std::fstream &stream);
    void readJSONArray(std::fstream &stream);
    void readJSONDataObject(std::fstream &stream);
    void readJSONDataItem(std::fstream &stream);
    std::string htmlString();
    std::string htmlBottom();
    std::string parseJSONString(std::string, char c, std::fstream &stream);
  //  Pair* getAlbum_Pair(int counter);
    std::vector<Pair *> album_vec;

private:
    std::string htmlBody;
    //std::string _artistID;
    /*std::string _title, _genre, _year, _albumIDString, _numTracksString, _numImagesString, _artistIDString;
    unsigned _albumID, _numTracks, _numImages, _artistID;
    std::fstream inputStream;
    std::string inputFileName;
    std::vector<std::string> album;
    std::string htmlStr;*/
    //std::ofstream fileStream;
};

#endif //Album.hpp
