#include "ArtistImage.hpp"

ArtistImage::ArtistImage(){

}

ArtistImage::~ArtistImage(){

}

std::string ArtistImage::artistID(){
    Pair * pair =  new Pair;
    pair = artistImage_vec[2];
    return pair->attributeName();
}

std::string ArtistImage::type(){
    Pair * pair = new Pair;
    pair = artistImage_vec[0];
    return pair->attributeName();
}

std::string ArtistImage::width() {
    Pair * pair = new Pair;
    pair = artistImage_vec[1];
    return pair->attributeName();
}

std::string ArtistImage::height(){
    Pair * pair = new Pair;
    pair = artistImage_vec[3];
    return pair->attributeName();
}
std::string ArtistImage::uri() {
    Pair * pair = new Pair;
    pair = artistImage_vec[4];
    return pair->attributeName();
}

void ArtistImage::readJSONDataObject(std::fstream &stream)
{
    char c;

    if( !(stream >> c) || c != '{' ) { // The first non-space character of a JSON object has to be '{'.
        // print some error message and exit the program.
        std::cout << "Something is wrong character is " << c << " while it should be a : '{'... exit ";
        exit(1);}
    do {
        Pair * pair = new Pair;
        pair->parsePair(stream);
        artistImage_vec.push_back(pair);
        stream >> c;
    } while( c != '}' );

}
