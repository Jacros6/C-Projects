#include "Album.hpp"

Album::~Album(){

}

Album::Album(const Album &old_artist){

}

Album::Album(std::fstream stream){

}

Album::Album(){

}

std::string Album::artistID() {
    Pair * pair = new Pair;
    pair = album_vec[2];
    return pair->attributeName();
}

std::string Album::albumID(){
    Pair * pair = new Pair;
    pair = album_vec[0];
    return pair->attributeName();
}

std::string Album::num_images() {
    Pair * pair = new Pair;
    pair = album_vec[6];
    return pair->attributeName();
}

std::string Album::num_tracks() {
    Pair * pair = new Pair;
    pair = album_vec[1];
    return pair->attributeName();
}

std::string Album::genre(){
    Pair * pair = new Pair;
    pair = album_vec[4];
    return pair->attributeName();
}

std::string Album::year() {
    Pair * pair = new Pair;
    pair = album_vec[5];
    return pair->attributeName();
}

std::string Album::title(){
    Pair * pair = new Pair;
    pair = album_vec[3];
    return pair->attributeName();
}

std::string Album::printAlbums(){
    htmlBody = "<br><tbody><tr>"+ album_vec[3]->attributeName() + "</tr></tbody><tbody><tr>Year:" + album_vec[5]->attributeName() +"</tr></tbody>"+
            "<tbody><tr>Genre: " + album_vec[4]->attributeName() + "</tr></tbody></br>";
    return htmlBody;
}

//Pair* Album::getAlbum_Pair(int counter) {
//    return album_vec[counter];
//}

void Album::readJSONDataObject(std::fstream &stream)
{
    char c;

    if( !(stream >> c) || c != '{' ) { // The first non-space character of a JSON object has to be '{'.
        // print some error message and exit the program.
        std::cout << "Something is wrong character is " << c << " while it should be a : '{'... exit ";
        exit(1);}
    do {
        Pair* pair = new Pair;
        pair->parsePair(stream); //change to parsepair function
        album_vec.push_back(pair);
        stream >> c;
    } while( c != '}' );

}

/*
std::string Album::htmlString(){
    htmlStr = "<!DOCTYPE html><html><head><title>Artists</title></head><body>"
              "<p>The following is a list of albums in the database.</p><ol>";
    fileStream << htmlStr;
    return "";
}

std::string Album::htmlBottom(){
    htmlStr = "</ol></body></html>";
    fileStream << htmlStr;
    return "";
}

std::string Album::htmlBuilder(){
    htmlStr = "<li><p>" + _title + "</p>" + "<ul>" + "<li><p>Album ID: " + _albumIDString + "</p></li>" + "<li><p>" +
            "Genre/Style: " + _genre + "</p></li>" + "<li><p>" + "Number of Videos: " + _numImagesString + "</p></li>" +
            "<li><p>"+ "Number of Tracks: " + _numTracksString + "</p></li>" + "<li><p>" + "Year: " + _year + "</p></li>"
            + "</ul>" + "</li>";
    fileStream << htmlStr;
    return "";
}*/
